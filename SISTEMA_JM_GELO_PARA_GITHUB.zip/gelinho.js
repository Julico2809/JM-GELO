<!-- Arquivo: gelinho.js do sistema JM Gelo -->
