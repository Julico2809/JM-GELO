<!-- Arquivo: vendas.js do sistema JM Gelo -->
