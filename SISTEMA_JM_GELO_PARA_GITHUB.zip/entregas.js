<!-- Arquivo: entregas.js do sistema JM Gelo -->
