<!-- Arquivo: financeiro.js do sistema JM Gelo -->
