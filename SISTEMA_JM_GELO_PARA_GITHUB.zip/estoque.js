<!-- Arquivo: estoque.js do sistema JM Gelo -->
