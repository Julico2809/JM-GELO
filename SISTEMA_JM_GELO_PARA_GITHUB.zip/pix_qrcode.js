<!-- Arquivo: pix_qrcode.js do sistema JM Gelo -->
