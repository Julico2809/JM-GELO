<!-- Arquivo: whatsapp.js do sistema JM Gelo -->
