// Script funcional: estoque.js
