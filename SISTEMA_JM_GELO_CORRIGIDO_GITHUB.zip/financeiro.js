// Script funcional: financeiro.js
