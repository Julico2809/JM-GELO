// Script funcional: painel.js
