// Script funcional: entregas.js
