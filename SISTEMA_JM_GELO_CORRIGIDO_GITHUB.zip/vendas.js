// Script funcional: vendas.js
