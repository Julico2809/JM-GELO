// Script funcional: catalogo.js
