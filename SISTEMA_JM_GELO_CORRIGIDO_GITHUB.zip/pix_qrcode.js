// Script funcional: pix_qrcode.js
