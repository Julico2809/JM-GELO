// Script funcional: whatsapp.js
