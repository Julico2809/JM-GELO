// Script funcional: gelinho.js
